<p align="center">
  <img src="https://coolthemestores.com/wp-content/uploads/2020/12/zero-two-feature.jpg">
</p>

# YEYEN BOT

<p align="center">
☆ " Hanya beberapa kode yang merupakan bot untuk bersenang-senang! " ☆
</p>

* Yeyen bot Link:  <a href="https://wa.me/6283162951046" alt="Yeyen"> <img src="https://img.shields.io/badge/%F0%9F%A4%96%20-YeyenBot-brightgreen" /> </a>

Jika Anda mem-forking repo ini, jangan lupa untuk memberi tanda bintang - <img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/adulalhy/yeyen?color=white&label=%F0%9F%8C%9F%20star">

## Install yang di butuhkan

```sh
$ pkg update -y
$ pkg upgrade -y
$ pkg install bash -y
$ pkg install git -y
```
## Install Yeyen bot

```sh
$ git clone https://github.com/adulalhy/yeyen.git
$ cd yeyen
$ bash install.sh
$ node index.js

Tinggal scan kode qr!
```
## Menjalankan bot ulang

```sh
$ cd yeyen
$ node index.js
```

## Credits 📍
* Nah, itu semua ada dalam sejarah komit
Jangan ragu untuk membuka permintaan tarik jika ada menemukam kesalahan

## Thanks to
* [ADUL](https://github.com/adulalhy)
* [RYNZ](https://github.com/riyan3334)
* [NAYLA](https://github.com/naylachan)
